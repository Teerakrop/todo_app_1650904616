class Task < ApplicationRecord
    enum status: { incomplete: 0, complete: 1 }
    validates :title, presence: true
  
    # เพิ่มเมธอดเพื่อเช็คสถานะของ Task
    def incomplete?
      !status
    end
  
    def complete?
      status
    end
  end
  